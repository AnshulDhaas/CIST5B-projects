Launching the ride sharing system:
    - Go to main.py, and then run the file, afterwards the GUI should pop up in a new window

Interacting with the ride sharing system:
    - In the browse button attach a csv file, then press load coordinates.
    - Do this twice and separately for a driver and passenger file.
    - You may want to generate your own file based on the attributes of the driver or passenger objects.
    - After loading the files with the passenger and driver coordinates, you can apply filters with the spinboxes and draw new connections by selecting a new driver in the listbox.
    - To exit the application you may close it and it will stop running.